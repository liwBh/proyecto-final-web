﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BebidasBackend.Entidades.Request
{
	public class ReqObtenerBebidas: ReqBase
	{
	}
}
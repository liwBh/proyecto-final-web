﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BebidasBackend.Entidades.Response
{
	public class ResObtenerBebidas : ResBase
	{
		public List<Bebida> ListaDeBebidas;
	}
}
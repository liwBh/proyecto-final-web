﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BebidasBackend.Entidades
{
	public class Bebida
	{
		public int id { get; set; }
		public string nombre { get; set; }
		public string preparacion { get; set; }
		public string tipoalcohol { get; set; }
		public int vasoid { get; set; }
		public int categoriaid { get; set; }
		
	}
}
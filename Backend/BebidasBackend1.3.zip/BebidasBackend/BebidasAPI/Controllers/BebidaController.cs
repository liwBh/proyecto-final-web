﻿using BebidasBackend.AccesoDatos;
using BebidasBackend.Entidades;
using BebidasBackend.Entidades.Enum;
using BebidasBackend.Entidades.Request;
using BebidasBackend.Entidades.Response;
using BebidasBackend.Logica;
using ForoBackend.Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace BebidasAPI.Controllers
{
    public class BebidaController : Controller
	{     // GET: dominio/api/bebida
		public ResObtenerBebidas Get()
		{
			ReqObtenerBebidas req = new ReqObtenerBebidas();
		

			LogBebida logicaDelBackend = new LogBebida();
			return logicaDelBackend.obtenerBebida(req);
		}

		 

		public ResIngresarBebida ingresarBebida([FromBody] ReqIngresarBebida req)
		{
			LogBebida logicaDelBackend = new LogBebida();
			return logicaDelBackend.insertarBebida(req);

		}

		public ResEliminarBebida eliminarBebida([FromBody] ReqEliminarBebida req)
		{
			LogBebida logicaDelBackend = new LogBebida();
			return logicaDelBackend.eliminarBebida(req);

		}

		public ResActualizarBebida actualizarBebida([FromBody] ReqActualizarBebida req)
		{
			LogBebida logicaDelBackend = new LogBebida();
			return logicaDelBackend.actualizarBebida(req);

		}


	}
}

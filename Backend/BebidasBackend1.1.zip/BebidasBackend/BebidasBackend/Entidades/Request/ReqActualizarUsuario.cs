﻿


namespace BebidasBackend.Entidades.Request
{
    public class ReqActualizarUsuario : ReqBase
    {
        public Usuario elUsuario { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using BebidasBackend.Entidades;
using ForoBackend.Logica;
using BebidasBackend.Entidades.Enum;
using BebidasBackend.Entidades.Response;
using BebidasBackend.Entidades.Request;
using BebidasBackend.AccesoDatos;

namespace BebidasBackend.Logica
{
	public class LogBebida
	{
		

		public ResObtenerBebidas obtenerBebidas(ReqObtenerBebidas req)
		{
			Int16 tipoDeTransaccion = 0;
			string descripcionError = "";
			int? errorId = 0;
			ResObtenerBebidas res = new ResObtenerBebidas();
			res.errors = new List<string>();

			try
			{


				conexionbdDataContext miLinq = new conexionbdDataContext();
				List<SP_OBTENER_TODAS_BEBIDASResult> listaDeLinq = new List<SP_OBTENER_TODAS_BEBIDASResult>();
				listaDeLinq = miLinq.SP_OBTENER_TODAS_BEBIDAS(ref errorId, ref descripcionError).ToList();
				res.ListaDeBebidas = this.crearListaDeBebidas(listaDeLinq);
				res.result = true;


			}
			catch (Exception ex)
			{
				res.result = false;
				tipoDeTransaccion = (Int16)enumTipo.errorNoControlado;
				descripcionError = ex.StackTrace;
				res.errors.Add(ex.StackTrace); //!!!!!!
			}
			finally
			{
				//	Utilitarios.bitacorear(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name, tipoDeTransaccion, (int)errorId, descripcionError, JsonConvert.SerializeObject(req), JsonConvert.SerializeObject(res));
			}
			return res;
		}

		private List<Bebida> crearListaDeBebidas(List<SP_OBTENER_TODAS_BEBIDASResult> listaDeLinq)
		{
			List<Bebida> listaArmada = new List<Bebida>();
			foreach (SP_OBTENER_TODAS_BEBIDASResult tipoComplejo in listaDeLinq)
			{
				listaArmada.Add(this.ingresarBebida(tipoComplejo));
			}
			return listaArmada;
		}



	

		public ResIngresarBebida ingresarBebida(ReqIngresarBebida req)
		{
			ResIngresarBebida res = new ResIngresarBebida();
			res.errors = new List<string>();
			Int16 tipoTransccion = 0;
			string descripcionError = "";
			int? errorId = 0;
			try
			{
				if (req == null)
				{
					res.result = false;
					res.errors.Add("Request null");
					tipoTransccion = (Int16)enumTipo.errorLogica;
				}
				else
				{
					if (String.IsNullOrEmpty(req.laBebida.nombre))
					{
						//Falta el nombre
						res.result = false;
						res.errors.Add("Nombre faltante");
					}
					if (String.IsNullOrEmpty(req.laBebida.preparacion))
					{
						res.result = false;
						res.errors.Add("Preparacion faltante");
					}
					if (String.IsNullOrEmpty(req.laBebida.tipoalcohol))
					{
						res.result = false;
						res.errors.Add("El Tipo No se agregó");
					}
					if ((req.laBebida.vasoid)==0)
					{
						res.result = false;
						res.errors.Add("Requiere un Vaso");
					}
					if ((req.laBebida.categoriaid) == 0 )
					{
						res.result = false;
						res.errors.Add("Requiere una categoria");
					}

					if (res.errors.Any())
					{
						//Hay errores
						tipoTransccion = (Int16)enumTipo.errorLogica;
					}
					else
					{
						//No hay errores
						//Mandar a AD
						long? idReturn = 0;
						int? idError = 0;
						string errorBD = "";

						Random rdm = new Random();
						int intNumeroVerificacion = rdm.Next();
					

						conexionbdDataContext miLinq = new conexionbdDataContext();
						miLinq.SP_INSERTAR_BEBIDA(req.laBebida.nombre, req.laBebida.preparacion, req.laBebida.tipoalcohol, req.laBebida.vasoid, req.laBebida.categoriaid,ref idReturn, ref idError, ref errorBD);

						if (idError == 0)
						{
						
							res.result = true;
							tipoTransccion = (Int16)enumTipo.exitoso;
							errorId = 0;
						}
						else
						{
							errorId = idError;
							descripcionError = errorBD;
							res.result = false;
							res.errors.Add(errorBD);
							tipoTransccion = (Int16)enumTipo.errorDeBaseDatos;
						}

					}
				}

			}
			catch (Exception ex)
			{
				descripcionError = ex.Message;
				res.result = false;
				res.errors.Add($"{ex.Message}");
				tipoTransccion = (Int16)enumTipo.errorNoControlado;

			}
			finally
			{
				//Bitacorear TODOOO lo que pasó (bueno o malo)
				//Utilitarios.bitacorear(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name, tipoTransccion, (int)errorId, descripcionError, JsonConvert.SerializeObject(req), JsonConvert.SerializeObject(res));
			}

			return res;
		}

		public ResObtenerBebidas obtenerBebida(ReqObtenerBebidas req)
		{
			throw new NotImplementedException();
		}

		public ResIngresarBebida insertarBebida(ReqIngresarBebida req)
		{
			throw new NotImplementedException();
		}

		public ResActualizarBebida actualizarBebida(ReqActualizarBebida req)
		{
			ResActualizarBebida res = new ResActualizarBebida();
			res.errors = new List<string>();
			Int16 tipoTransccion = 0;
			string descripcionError = "";
			int? errorId = 0;

			//Validaciones
			try
			{
				if (req == null)
				{
					res.result = false;
					res.errors.Add("Request null");
					tipoTransccion = (Int16)enumTipo.errorLogica;
				}
				else
				{
					if (String.IsNullOrEmpty(req.laBebida.nombre))
					{
						//Falta el nombre
						res.result = false;
						res.errors.Add("Nombre faltante");
					}
					if (String.IsNullOrEmpty(req.laBebida.preparacion))
					{
						res.result = false;
						res.errors.Add("Preparacion faltantes");
					}
					if (String.IsNullOrEmpty(req.laBebida.tipoalcohol))
					{
						res.result = false;
						res.errors.Add("Falta tipo de alcohol");
					}
					if (req.laBebida.vasoid==0)
					{
						res.result = false;
						res.errors.Add("Agregue el vaso");
					}
					if (req.laBebida.categoriaid==0)
					{
						res.result = false;
						res.errors.Add("Agregue la categoria");
					}


					if (res.errors.Any())
					{
						//Hay errores
						tipoTransccion = (Int16)enumTipo.errorLogica;
					}
					else
					{
						//No hay errores
						//Mandar a AD
						int? idReturn = 0;
						int? idError = 0;
						string errorBD = "";
					
						conexionbdDataContext miLinq = new conexionbdDataContext();
						miLinq.SP_ACTUALIZAR_BEBIDA(req.laBebida.id, req.laBebida.nombre, req.laBebida.preparacion, req.laBebida.tipoalcohol, req.laBebida.vasoid, req.laBebida.categoriaid,ref errorId, ref descripcionError);


						if (idError == 0)
						{
							
							res.result = true;
							tipoTransccion = (Int16)enumTipo.exitoso;
							errorId = 0;
						}
						else
						{
							errorId = idError;
							descripcionError = errorBD;
							res.result = false;
							res.errors.Add(errorBD);
							tipoTransccion = (Int16)enumTipo.errorDeBaseDatos;
						}


					}

				}
			}
			catch (Exception ex)
			{

				descripcionError = ex.Message;
				res.result = false;
				res.errors.Add($"{ex.Message}");
				tipoTransccion = (Int16)enumTipo.errorNoControlado;

			}
			finally
			{
				//Bitácora
			}


			return res;

		}
		public ResEliminarBebida eliminarBebida(ReqEliminarBebida req)
		{
			ResEliminarBebida res = new ResEliminarBebida();
			res.errors = new List<string>();
			Int16 tipoTransccion = 0;
			string descripcionError = "";
			int? errorId = 0;

			//Validaciones
			try
			{
				if (req == null)
				{
					res.result = false;
					res.errors.Add("Request null");
					tipoTransccion = (Int16)enumTipo.errorLogica;
				}
				else
				{
					if (req.laBebida.id == null)
					{
						
						res.result = false;
						res.errors.Add("Ningún ID enviado");
					}

					if (res.errors.Any())
					{
						//Hay errores
						tipoTransccion = (Int16)enumTipo.errorLogica;
					}
					else
					{
						//No hay errores
						//Mandar a AD
						int? idReturn = 0;
						int? idError = 0;
						string errorBD = "";

						conexionbdDataContext miLinq = new conexionbdDataContext();
						miLinq.SP_ELIMINAR_USUARIO(req.laBebida.id, ref errorId, ref descripcionError);


						if (idError == 0)
						{
							
							//  Utilitarios.enviarCorreoElectronico(req.elUsuario.correoElectronico, strNumeroVerificacion);

							res.result = true;
							tipoTransccion = (Int16)enumTipo.exitoso;
							errorId = 0;
						}
						else
						{
							errorId = idError;
							descripcionError = errorBD;
							res.result = false;
							res.errors.Add(errorBD);
							tipoTransccion = (Int16)enumTipo.errorDeBaseDatos;
						}


					}

				}
			}
			catch (Exception ex)
			{

				descripcionError = ex.Message;
				res.result = false;
				res.errors.Add($"{ex.Message}");
				tipoTransccion = (Int16)enumTipo.errorNoControlado;

			}
			finally
			{
				//Bitácora
			}


			return res;

		}

	}
}
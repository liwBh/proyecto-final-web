﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BebidasBackend.Entidades
{
	public class ResActivarUsuario : ResBase
	{
		public string sesion { get; set; }
	}
}